<?php $__env->startSection('container'); ?>
<main>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Products</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item">
                <a href="index.html">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Produk</li>
        </ol>
        <div class="card mb-4">
            <div class="card-body">
                DataTables is a third party plugin that is used to generate the
                demo table below. For more information about DataTables, please
                visit the
                <a target="_blank" href="https://datatables.net/"
                >official DataTables documentation</a
                >
                .
            </div>
        </div>
        <div class="card mb-4">
            <div class="card-header">
            <i class="fas fa-table me-1"></i>
            DataTable Example
            </div>
            <div class="card-body">
                <table id="datatablesSimple">
                    <thead>
                        <tr>
                            <th>ID Inventory</th>
                            <th>Nama Barang</th>
                            <th>Kategori Barang</th>
                            <th>Kode Barcode</th>
                            <th>Tanggal dan Jam</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $inventory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($item->id_inventory); ?></td>
                                <td><?php echo e($item->nama_barang); ?></td>
                                <td><?php echo e($item->kategori_barang); ?></td>
                                <td><?php echo e($item->kode_barcode); ?></td>
                                <td><?php echo e($item->create_date); ?></td>
                                <td>
                                    <a href="<?php echo e(route('inventory.edit', $item->id_inventory)); ?>" class="btn btn-primary">Edit</a>
                                    <a class="btn btn-danger">
                                        <form action="<?php echo e(route('inventory.destroy', $item->id_inventory)); ?>" method="POST" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit">Hapus</button>
                                        </form>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6">Tidak ada data produk.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DevProjects\IoT-Projects\Web-IoT\IoT2-Webapp-QR-Code-Scanner\barcode-scanner-app\resources\views/products.blade.php ENDPATH**/ ?>